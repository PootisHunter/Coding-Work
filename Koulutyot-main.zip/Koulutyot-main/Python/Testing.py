aika = 10
alkoholin_määrä = 3
def koodaus():
    return 1


jäljellä_oleva_aika = 24 / aika
suuri = alkoholin_määrä / aika
vitutus = suuri

def tee_töitä():
    koodaus()

while vitutus < jäljellä_oleva_aika:
    tee_töitä()


    