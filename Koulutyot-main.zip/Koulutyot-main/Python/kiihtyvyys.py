﻿x_0 = 50
v_0 = 100
a = 10
t = 5

print(v_0 + a * t)
print(x_0 + v_0 * t + 0.5 * a * t ** 2)