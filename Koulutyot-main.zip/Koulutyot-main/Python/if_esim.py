luku = int(input("Anna kokonaisluku: "))
if luku < 10:
    print("Luku on pienempi kuin 10")
elif luku < 100:
    print("Luku on pienempi kuin 100")
elif luku < 1000:
    print("Luku on pienempi kuin 1000")
