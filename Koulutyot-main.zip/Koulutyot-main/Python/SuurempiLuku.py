luku = int(input("Anna kokonaisluku: "))

if luku > 1000:
    print("Luku on suurempi kuin 1000")
elif luku > 100:
    print("Luku on suurempi kuin 100")
elif luku > 10:
    print("Luku on suurempi kuin 10")
