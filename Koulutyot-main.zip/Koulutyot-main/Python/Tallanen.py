rivi = "if elain == \"aasi\":"
if rivi.endswith(":"):
    true
else
    false