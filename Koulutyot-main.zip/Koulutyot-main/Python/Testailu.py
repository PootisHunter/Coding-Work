koordinaatit = [[1, 2], [3, 6], [6, 9]] 

for x, y in koordinaatit:
    print(x, y)

for x, y in enumerate(koordinaatit):
    print(x, y)

for x in range(0,(len(koordinaatit))):
    print(x)