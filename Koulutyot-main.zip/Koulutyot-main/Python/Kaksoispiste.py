teksti = """ 
   ...: asiahan on niin, että ohjelmointi on hauskaa kunnes javascript tapahtuu -  
   ...: sen jälkeen putoat loputtomaan tyhjyyteen 
   ...: """


print(teksti.count("python")) :

end

 #teksti.count("python") >= 1 and teksti.count("ohjelmointi") >= 1 :
 if teksti.count("python") >= 1 and teksti.count("ohjelmointi") >= 1:
 
 x = 5
 y = 6
 asia = "aasi"
 
 print("Ruudusta ({x}, {y}) löytyy {asia}.".format(x=x, y=y, asia=asia))
 
print("Kello on {tunnit:02}:{minuutit:02}".format(tunnit=tunnit, minuutit=minuutit))

inventaario = {
    "aasi": 15,
    "sininen ampari": 0,
    "epatoivoinen mursu": 1
}
    