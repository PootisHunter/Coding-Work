pituus = 45.572622
kerroin = 45.689372
korkeus = 93
print('Hemulin ominaisuudet: {}, {}, {}'.format(round(pituus, 2), round(kerroin, 2), korkeus)):
input('close')