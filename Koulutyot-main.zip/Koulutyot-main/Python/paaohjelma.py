def paaohjelma():
    try:
        print(input(": "))
    except KeyboardInterrupt:
        print("Terve ja kiitos kaloista") 

paaohjelma()