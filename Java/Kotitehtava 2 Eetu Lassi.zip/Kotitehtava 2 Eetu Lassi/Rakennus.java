
public class Rakennus {
    // Muuttujat
    private int RakennusAsukkaat, RakennusHuoneet;
    private Double RakennusPintaala;
    private Asukas [] asukas;

    public Rakennus(int Asukkaat, int Huoneet, Double Pintaala){
        this.RakennusAsukkaat = Asukkaat;
        this.RakennusHuoneet = Huoneet;
        this.RakennusPintaala = Pintaala;
        
    }
    
    public Asukas [] getAsukas() {
        return asukas;
    }

    public void setAsukas(Asukas [] asukas) {
        this.asukas = asukas;
    }

    public void Asukkaat(int Asukkaat){
        this.RakennusAsukkaat = Asukkaat;
    }

    public void Huoneet(int Huoneet){
        this.RakennusHuoneet = Huoneet;
    }

    public void Pintaala(Double Pintaala){
        if(Pintaala >= 0){
            this.RakennusPintaala = Pintaala;
        }
        else{
            System.out.println("Arvo ei saa olla negatiivinen");
            System.exit(0);
        }

    }
            

    public int TAsukkaat(){
        return RakennusAsukkaat;
    }

    public int THuoneet(){
        return RakennusHuoneet;
    }

    public Double TPintaala(){
        return RakennusPintaala;
    }

    public void LueRakennusTiedot(){
        System.out.println(
            "Asukkaat: " + RakennusAsukkaat + "\n" +
            "Huoneet: " + RakennusHuoneet + "\n" +
            "Pinta-ala: " + RakennusPintaala + "\n");
    }
}
