import java.util.Scanner;
public class Main {

    public static void main(String [] args){

        Scanner scanner = new Scanner(System.in);
        Tontti tontti = new Tontti("", "", "", 0.0);
        Rakennus rakennus = new Rakennus(0, 0, 0.0);
        
        int n;
        
        System.out.println("Anna tontin nimi: ");
        tontti.Nimi(scanner.nextLine());

        System.out.println("Anna tontin koordinaatit leveytena: ");
        tontti.SijaintiL(scanner.nextLine());

        System.out.println("Anna tontin koordinaatit pituutena: ");
        tontti.SijaintiP(scanner.nextLine());

        System.out.println("Anna tontin pinta-ala lukuna: ");
        tontti.Pintaala(scanner.nextDouble());
        scanner.nextLine();

        System.out.println("Anna Rakennuksen asukkaat lukuna: ");
        n = scanner.nextInt();
        rakennus.Asukkaat(n);
        scanner.nextLine();

        System.out.println("Anna Rakennuksen huoneet lukuna: ");
        rakennus.Huoneet(scanner.nextInt());
        scanner.nextLine();

        System.out.println("Anna Rakennuksen pinta-ala lukuna: ");
        rakennus.Pintaala(scanner.nextDouble());
        scanner.nextLine();

        Asukas [] asukkaat = new Asukas[n];
        for(int i = 0; i < n; i++){
            asukkaat[i] = new Asukas("","");

            System.out.println("Anna Asukkaan nimi: ");
            asukkaat[i].Asukkaat(scanner.nextLine());

            System.out.println("Anna Asukkaan Syntymäaika: ");
            asukkaat[i].Syntyma(scanner.nextLine());

        }
        
        tontti.LueTonttiTiedot();
        rakennus.LueRakennusTiedot();
        System.out.println("Asukkaat:");

        for(int i = 0; i < n; i++){
            asukkaat[i].LueAsukasTiedot();
        }
        System.out.println("*****" + "\n");
        scanner.close();

    }
    
}
