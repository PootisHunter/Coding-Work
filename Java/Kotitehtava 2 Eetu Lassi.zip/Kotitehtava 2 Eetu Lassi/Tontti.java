
public class Tontti {
    // Muuttujat
    private String TontinNimi, TontinSijaintiL, TontinSijaintiP;
    private Double TontinPintaala;


    public Tontti(String Nimi, String SijaintiL, String SijaintiP, Double Pintaala){
        this.TontinNimi = Nimi;
        this.TontinSijaintiL = SijaintiL;
        this.TontinSijaintiP = SijaintiP;
        this.TontinPintaala = Pintaala;
    }
        

    public void Nimi(String Nimi){
        this.TontinNimi = Nimi;
    }

    public void SijaintiL(String Sijainti){
        this.TontinSijaintiL = Sijainti;
    }

    public void SijaintiP(String Sijainti){
        this.TontinSijaintiP = Sijainti;
    }

    public void Pintaala(Double Pintaala){
        if(Pintaala >= 0){
            this.TontinPintaala = Pintaala;
        }
        else{
            System.out.println("Arvo ei saa olla negatiivinen");
            System.exit(0);
        }
        
    }

    public String TNimi(){
        return TontinNimi;
    }

    public String TSijaintiL(){
        return TontinSijaintiL;
    }

    public String TSijaintiP(){
        return TontinSijaintiP;
    }

    public Double TPintaala(){
        return TontinPintaala;
    }
    public void LueTonttiTiedot(){
        System.out.println(
            "*****" + "\n" +
            "Tontin nimi: " + TontinNimi + "\n" +
            "Sijainti: " + TontinSijaintiL + " " + TontinSijaintiP + "\n" +
            "Pinta-ala: " + TontinPintaala + "\n");
    }
}
